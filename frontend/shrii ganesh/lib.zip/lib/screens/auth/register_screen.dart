import 'package:flutter/material.dart';
import '../../services/firebase_auth_service.dart';
import '../mpin/create_mpin_screen.dart';
import '../../services/local_storage_service.dart';

class RegisterScreen extends StatefulWidget {
  const RegisterScreen({super.key});

  @override
  State<RegisterScreen> createState() => _RegisterScreenState();
}

class _RegisterScreenState extends State<RegisterScreen> {

  final nameController = TextEditingController();

  final mobileController = TextEditingController();

  final emailController = TextEditingController();

  final passwordController = TextEditingController();

  final confirmPasswordController =
  TextEditingController();

  final AuthService authService = AuthService();

  @override
  Widget build(BuildContext context) {

    return Scaffold(
      appBar: AppBar(
        title: const Text("Create Account"),
      ),

      body: Padding(
        padding: const EdgeInsets.all(20),

        child: Column(
          children: [

            TextField(
              controller: nameController,
              decoration: const InputDecoration(
                labelText: "Full Name",
              ),
            ),

            const SizedBox(height: 15),

            TextField(
              controller: mobileController,
              keyboardType: TextInputType.phone,
              decoration: const InputDecoration(
                labelText: "Mobile Number",
                prefixIcon: Icon(Icons.phone),
              ),
            ),

            const SizedBox(height: 15),

            TextField(
              controller: emailController,
              decoration: const InputDecoration(
                labelText: "Email",
              ),
            ),

            const SizedBox(height: 15),

            TextField(
              controller: passwordController,
              obscureText: true,
              decoration: const InputDecoration(
                labelText: "Password",
              ),
            ),

            const SizedBox(height: 15),

            TextField(
              controller: confirmPasswordController,
              obscureText: true,
              decoration: const InputDecoration(
                labelText: "Confirm Password",
                prefixIcon: Icon(Icons.lock),
              ),
            ),

            const SizedBox(height: 25),

            ElevatedButton(

              onPressed: () async {

                if (nameController.text.trim().isEmpty ||
                    mobileController.text.trim().isEmpty ||
                    passwordController.text.trim().isEmpty) {

                  ScaffoldMessenger.of(context).showSnackBar(
                    const SnackBar(
                      content: Text("Please fill all required fields"),
                    ),
                  );

                  return;
                }

                if (passwordController.text !=
                    confirmPasswordController.text) {

                  ScaffoldMessenger.of(context).showSnackBar(
                    const SnackBar(
                      content: Text("Passwords do not match"),
                    ),
                  );

                  return;
                }

                String? result =
                await authService.registerUser(

                  email: emailController.text.trim(),

                  password:
                  passwordController.text.trim(),

                );

                if (result == null) {

                  await LocalStorageService.saveUser(

                    name: nameController.text.trim(),

                    mobile: mobileController.text.trim(),

                    email: emailController.text.trim(),

                  );

                  if (!mounted) return;

                  ScaffoldMessenger.of(context).showSnackBar(

                    const SnackBar(

                      content: Text(
                        "Registration Successful",
                      ),

                    ),

                  );

                  Navigator.pushReplacement(

                    context,

                    MaterialPageRoute(

                      builder: (_) =>
                      const CreateMpinScreen(),

                    ),

                  );

                } else {

                  if (!mounted) return;

                  ScaffoldMessenger.of(context).showSnackBar(

                    SnackBar(

                      content: Text(result),

                    ),

                  );
                }
              },
              child: const Text("Create Account"),
            )
          ],
        ),
      ),
    );
  }

  @override
  void dispose() {

    nameController.dispose();
    mobileController.dispose();
    emailController.dispose();
    passwordController.dispose();
    confirmPasswordController.dispose();

    super.dispose();
  }

}