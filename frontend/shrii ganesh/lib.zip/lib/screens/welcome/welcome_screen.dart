import 'package:flutter/material.dart';

import '../../services/local_storage_service.dart';
import '../auth/register_screen.dart';
import '../mpin/verify_mpin_screen.dart';

class WelcomeScreen extends StatefulWidget {
  const WelcomeScreen({super.key});

  @override
  State<WelcomeScreen> createState() => _WelcomeScreenState();
}

class _WelcomeScreenState extends State<WelcomeScreen> {

  Future<void> navigate() async {

    bool registered =
    await LocalStorageService.isRegistered();

    if (!mounted) return;

    if (registered) {

      Navigator.pushReplacement(
        context,
        MaterialPageRoute(
          builder: (_) =>
          const VerifyMpinScreen(),
        ),
      );

    } else {

      Navigator.pushReplacement(
        context,
        MaterialPageRoute(
          builder: (_) =>
          const RegisterScreen(),
        ),
      );

    }
  }

  @override
  Widget build(BuildContext context) {

    return Scaffold(

      body: Container(

        width: double.infinity,

        decoration: const BoxDecoration(

          gradient: LinearGradient(

            colors: [

              Color(0xFF5ED3C5),

              Color(0xFFB6F0E8),

            ],

            begin: Alignment.topCenter,

            end: Alignment.bottomCenter,

          ),
        ),

        child: SafeArea(

          child: Padding(

            padding: const EdgeInsets.all(24),

            child: Column(

              mainAxisAlignment:
              MainAxisAlignment.spaceBetween,

              children: [

                const SizedBox(),

                Column(

                  children: [

                    Image.asset(
                      "assets/icons/logo.png",
                      height: 140,
                    ),

                    const SizedBox(height: 25),

                    const Text(

                      "Welcome to Samvya",

                      style: TextStyle(

                        fontSize: 30,

                        fontWeight: FontWeight.bold,

                        color: Colors.white,

                      ),

                    ),

                    const SizedBox(height: 10),

                    const Text(

                      "Empowering Rural Banking\nSecure • Simple • Smart",

                      textAlign: TextAlign.center,

                      style: TextStyle(

                        color: Colors.white70,

                        fontSize: 18,

                      ),

                    ),

                  ],
                ),

                SizedBox(

                  width: double.infinity,

                  height: 55,

                  child: ElevatedButton(

                    onPressed: navigate,

                    style: ElevatedButton.styleFrom(

                      backgroundColor: Colors.white,

                      shape: RoundedRectangleBorder(

                        borderRadius:
                        BorderRadius.circular(18),

                      ),

                    ),

                    child: const Text(

                      "GET STARTED",

                      style: TextStyle(

                        color: Color(0xFF5ED3C5),

                        fontWeight: FontWeight.bold,

                        fontSize: 18,

                      ),

                    ),

                  ),

                ),

              ],
            ),
          ),
        ),
      ),
    );
  }
}