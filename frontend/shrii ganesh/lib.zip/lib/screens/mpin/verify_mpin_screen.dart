import 'package:flutter/material.dart';
import '../../services/local_storage_service.dart';
import '../auth/register_screen.dart';
import '../dashboard/main_dashboard.dart';

class VerifyMpinScreen extends StatefulWidget {
  const VerifyMpinScreen({super.key});

  @override
  State<VerifyMpinScreen> createState() => _VerifyMpinScreenState();
}

class _VerifyMpinScreenState extends State<VerifyMpinScreen> {

  final TextEditingController mpinController =
  TextEditingController();

  Future<void> verifyMpin() async {

    String? savedMpin =
    await LocalStorageService.getMPIN();

    if (savedMpin == mpinController.text.trim()) {

      if (!mounted) return;

      Navigator.pushReplacement(
        context,
        MaterialPageRoute(
          builder: (_) => const MainDashboard(),
        ),
      );

    } else {

      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text("Incorrect MPIN"),
        ),
      );
    }
  }

  @override
  Widget build(BuildContext context) {

    return Scaffold(

      backgroundColor: Colors.grey.shade100,

      body: SafeArea(

        child: Padding(

          padding: const EdgeInsets.all(20),

          child: Column(

            mainAxisAlignment: MainAxisAlignment.center,

            children: [

              const CircleAvatar(
                radius: 45,
                backgroundColor: Colors.teal,
                child: Icon(
                  Icons.lock,
                  color: Colors.white,
                  size: 40,
                ),
              ),

              const SizedBox(height: 20),

              const Text(
                "Welcome Back",
                style: TextStyle(
                  fontSize: 28,
                  fontWeight: FontWeight.bold,
                ),
              ),

              const SizedBox(height: 10),

              const Text(
                "Enter your 4 digit MPIN",
                style: TextStyle(
                  color: Colors.grey,
                ),
              ),

              const SizedBox(height: 40),

              TextField(

                controller: mpinController,

                keyboardType: TextInputType.number,

                obscureText: true,

                maxLength: 4,

                textAlign: TextAlign.center,

                style: const TextStyle(
                  fontSize: 25,
                  letterSpacing: 12,
                ),

                decoration: InputDecoration(

                  hintText: "••••",

                  border: OutlineInputBorder(
                    borderRadius:
                    BorderRadius.circular(15),
                  ),

                ),
              ),

              const SizedBox(height: 30),

              SizedBox(

                width: double.infinity,

                height: 55,

                child: ElevatedButton(

                  onPressed: verifyMpin,

                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.teal,
                  ),

                  child: const Text(
                    "LOGIN",
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: 18,
                    ),
                  ),
                ),
              ),

              const SizedBox(height: 20),

              TextButton(

                onPressed: () {

                  ScaffoldMessenger.of(context)
                      .showSnackBar(

                    const SnackBar(
                      content: Text(
                        "Forgot MPIN Coming Soon",
                      ),
                    ),

                  );

                },

                child: const Text(
                  "Forgot MPIN?",
                ),

              ),

              const SizedBox(height: 20),

              const Divider(),

              const SizedBox(height: 10),

              const Text(
                "New User?",
                style: TextStyle(
                  fontWeight: FontWeight.bold,
                ),
              ),

              TextButton(

                onPressed: () {

                  Navigator.push(

                    context,

                    MaterialPageRoute(

                      builder: (_) =>
                      const RegisterScreen(),

                    ),

                  );

                },

                child: const Text(
                  "Register Here",
                ),
              ),

            ],
          ),
        ),
      ),
    );
  }

  @override
  void dispose() {

    mpinController.dispose();

    super.dispose();
  }
}