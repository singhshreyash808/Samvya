import 'package:local_auth/local_auth.dart';

class BiometricService {
  static final LocalAuthentication auth = LocalAuthentication();

  static Future<bool> authenticate() async {
    try {
      bool isSupported = await auth.isDeviceSupported();
      print("Device Supported: $isSupported");

      bool canCheck = await auth.canCheckBiometrics;
      print("Can Check Biometrics: $canCheck");

      List<BiometricType> available =
      await auth.getAvailableBiometrics();

      print("Available Biometrics: $available");

      bool authenticated = await auth.authenticate(
        localizedReason: "Authenticate to access Samvya",
        options: const AuthenticationOptions(
          biometricOnly: true,
          stickyAuth: true,
        ),
      );

      print("Authenticated: $authenticated");

      return authenticated;

    } catch (e) {
      print("Biometric Error: $e");
      return false;
    }
  }
}